from flask import Flask, render_template, request,make_response

app = Flask(__name__)

@app.route("/")
def i():
    return render_template("home.html")

notes=[]
@app.route("/", methods=["get","post"])
def index():
    note = request.form.get("note")
    notes.append(note)
    res = make_response( render_template("home.html", notes=notes),200)
    res.set_cookie(
        "flavour","note",
         secure=True
         )
    
    return res
@app.route("/get-cookie/")
def get_cookie():
    username=request.cookies.get("flavour")
if __name__ == '__main__':
    app.run(debug=True)