#step 1 : import Flask( flask is module Flask is class
from flask import Flask,request

#step 2 : app is the object we are creating for Flask class with the parameter __name__
app = Flask(__name__)

#step 3 : create an endpoint using route and bind them with a functionality
@app.route('/')
def home_page1():
    return "Welcome to the Search page"

@app.route('/home_page')
def home_page():
    return "This is first home page"

@app.route('/upper')
def word():
    a=request.args.get("a")
    return str(a).upper()


#step 4 : run the app
if __name__ == '__main__':
    app.run()
